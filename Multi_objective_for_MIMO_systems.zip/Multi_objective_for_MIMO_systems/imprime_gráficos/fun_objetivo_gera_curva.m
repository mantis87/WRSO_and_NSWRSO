function [Y_solucoes] = fun_objetivo_gera_curva(x,est)
 load SANEPAR_COMPLETO.txt
u1e = SANEPAR_COMPLETO(est,1)';
u2e = SANEPAR_COMPLETO(est,2)';
u3e = SANEPAR_COMPLETO(est,3)';
u4e = SANEPAR_COMPLETO(est,4)';
U = [u1e;u2e;u3e;u4e];
y1e = SANEPAR_COMPLETO(est,5)';
y2e = SANEPAR_COMPLETO(est,6)';
y3e = SANEPAR_COMPLETO(est,7)';
Y = [y1e;y2e;y3e];
tam = length(Y);
Np = size(x,2);

a11 = x(1,:);
a21 = x(2,:);
a31 = x(3,:);
a112 = x(4,:);
a212 = x(5,:);
a312 = x(6,:);
a113 = x(7,:);
a213 = x(8,:);
a313 = x(9,:);
b11 = x(10,:);
b21 = x(11,:);
b31 = x(12,:);
c11 = x(13,:);
c21 = x(14,:);
c31 = x(15,:);
d11 = x(16,:);
d21 = x(17,:);
d31 = x(18,:);
e11 = x(19,:);
e21 = x(20,:);
e31 = x(21,:);
ey11 = x(22,:);
ey12 = x(23,:);
ey13 = x(24,:);

a12 = x(25,:);
a22 = x(26,:);
a32 = x(27,:);
a121 = x(28,:);
a221 = x(29,:);
a321 = x(30,:);
a123 = x(31,:);
a223 = x(32,:);
a323 = x(33,:);
b12 = x(34,:);
b22 = x(35,:);
b32 = x(36,:);
c12 = x(37,:);
c22 = x(38,:);
c32 = x(39,:);
d12 = x(40,:);
d22 = x(41,:);
d32 = x(42,:);
e12 = x(43,:);
e22 = x(44,:);
e32 = x(45,:);
ey21 = x(46,:);
ey22 = x(47,:);
ey23 = x(48,:);

a13 = x(49,:);
a23 = x(50,:);
a33 = x(51,:);
a131 = x(52,:);
a231 = x(53,:);
a331 = x(54,:);
a132 = x(55,:);
a232 = x(56,:);
a332 = x(57,:);
b13 = x(58,:);
b23 = x(59,:);
b33 = x(60,:);
c13 = x(61,:);
c23 = x(62,:);
c33 = x(63,:);
d13 = x(64,:);
d23 = x(65,:);
d33 = x(66,:);
e13 = x(67,:);
e23 = x(68,:);
e33 = x(69,:);
ey31 = x(70,:);
ey32 = x(71,:);
ey33 = x(72,:);

y1_1 = [0 Y(1,1:tam-1)]'; 
y2_1 = [0 Y(2,1:tam-1)]'; 
y3_1 = [0 Y(3,1:tam-1)]'; 

y1_2 = [0 0 Y(1,1:tam-2)]'; 
y2_2 = [0 0 Y(2,1:tam-2)]'; 
y3_2 = [0 0 Y(3,1:tam-2)]';

y1_3 = [0 0 0 Y(1,1:tam-3)]'; 
y2_3 = [0 0 0 Y(2,1:tam-3)]'; 
y3_3 = [0 0 0 Y(3,1:tam-3)]'; 



u1_1 = [0 U(1,1:tam-1)]'; 
u2_1 = [0 U(2,1:tam-1)]'; 
u3_1 = [0 U(3,1:tam-1)]'; 
u4_1 = [0 U(4,1:tam-1)]';

u1_2 = [0 0 U(1,1:tam-2)]'; 
u2_2 = [0 0 U(2,1:tam-2)]'; 
u3_2 = [0 0 U(3,1:tam-2)]'; 
u4_2 = [0 0 U(4,1:tam-2)]'; 

u1_3 = [0 0 0 U(1,1:tam-3)]'; 
u2_3 = [0 0 0 U(2,1:tam-3)]'; 
u3_3 = [0 0 0 U(3,1:tam-3)]'; 
u4_3 = [0 0 0 U(4,1:tam-3)]';

          
           U1 = u1_1*b11 + u1_2*b21 + u1_3*b31;
           U2 = u2_1*c11 + u2_2*c21 + u2_3*c31;
           U3 = u3_1*d11 + u3_2*d21 + u3_3*d31;
           U4 = u4_1*e11 + u4_2*e21 + u4_3*e31;
           Y2 = - y2_1*a112 - y2_2*a212 - y2_3*a312;
           Y3 = - y3_1*a113 - y3_2*a213 - y3_3*a313;
           Yw1= - y1_1*a11 - y1_2*a21 - y1_3*a31 + Y2 + Y3 + U1 + U2 + U3 + U4;
           
           U1 = u1_1*b12 + u1_2*b22 + u1_3*b32;
           U2 = u2_1*c12 + u2_2*c22 + u2_3*c32;
           U3 = u3_1*d12 + u3_2*d22 + u3_3*d32;
           U4 = u4_1*e12 + u4_2*e22 + u4_3*e32;
           Y1 =- y1_1*a121 - y1_2*a221 - y1_3*a321;
           Y3 =- y3_1*a123 - y3_2*a223 - y3_3*a323;
           Yw2= - y2_1*a12 - y2_2*a22 - y2_3*a32 + Y1 + Y3 + U1 + U2 + U3 + U4;
 
           U1 = u1_1*b13 + u1_2*b23 + u1_3*b33;
           U2 = u2_1*c13 + u2_2*c23 + u2_3*c33;
           U3 = u3_1*d13 + u3_2*d23 + u3_3*d33;
           U4 = u4_1*e13 + u4_2*e23 + u4_3*e33;
           Y1 = - y1_1*a131 - y1_2*a231 - y1_3*a331;
           Y2 = - y2_1*a132 - y2_2*a232 - y2_3*a332;
           Yw3= - y3_1*a13 - y3_2*a23 - y3_3*a33 + Y1 + Y2 + U1 + U2 + U3 + U4;
 
            for k=1:3
             Yw1(k,:) = Y(1,k)*ones(1,Np);
             Yw2(k,:) = Y(2,k)*ones(1,Np);
             Yw3(k,:) = Y(3,k)*ones(1,Np);
            end      
            
            E1 = (Y(1,:)')*ones(1,Np) - Yw1;
            E2 = (Y(2,:)')*ones(1,Np) - Yw2;
            E3 = (Y(3,:)')*ones(1,Np) - Yw3;
            
            
        e1_1 = [zeros(1,Np);E1(1:tam-1,:)]; 
        e2_1 = [zeros(1,Np);E2(1:tam-1,:)]; 
        e3_1 = [zeros(1,Np);E3(1:tam-1,:)]; 

        e1_2 = [zeros(2,Np); E1(1:tam-2,:)]; 
        e2_2 = [zeros(2,Np); E2(1:tam-2,:)]; 
        e3_2 = [zeros(2,Np); E3(1:tam-2,:)]; 

        e1_3 = [zeros(3,Np); E1(1:tam-3,:)]; 
        e2_3 = [zeros(3,Np); E2(1:tam-3,:)]; 
        e3_3 = [zeros(3,Np); E3(1:tam-3,:)];
        
      
      Ew1 =  e1_1.*ey11 + e1_2.*ey12 + e1_3.*ey13; 
      Ew2 =  e2_1.*ey21 + e2_2.*ey22 + e2_3.*ey23; 
      Ew3 =  e3_1.*ey31 + e3_2.*ey32 + e3_3.*ey33; 
      
      E1 = sum((E1 - Ew1).^2);
      E2 = sum((E2 - Ew2).^2);
      E3 = sum((E3 - Ew3).^2);
      
      Yw = [(Yw1+Ew1)';(Yw2+Ew2)';(Yw3+Ew3)'];
      Y_solucoes = {Yw'}; 
% 
%  MSE1 = E1/tam;   
%  MSE2 = E2/tam;
%  MSE3 = E3/tam;  
% 
%  MSEG_best = [MSE1;MSE2;MSE3];
%  ym = mean(Y')';
%  Ym = ym*ones(1,tam);
%  ee=(Y-Ym).^2;
%  e2 = ee';
%  b = sum(e2);
%  R2_1 = 1 - E1/b(1);   
%  R2_2 = 1 - E2/b(2);
%  R2_3 = 1 - E3/b(3);  
% 
%  R2G_best = [R2_1;R2_2;R2_3]; 
%  figure(1)
% 
% ye=Y_solucoes{1,1};
% 
% %Validação
% subplot 311
% plot(Y(1,:))
% hold on
% plot(ye(:,1))
% subplot 312
% plot(Y(2,:))
% hold on
% plot(ye(:,2))
% subplot 313
% plot(Y(3,:))
% hold on
% plot(ye(:,3))


end