%_________________________________________________________________________%
%  Rat Swarm Optimizer (RSO)                                              %
%                                                                         %
%  Developed in MATLAB R2019b                                             %
%                                                                         %
%  Designed and Developed: Dr. Gaurav Dhiman                              %
%                                                                         %
%         E-Mail: gdhiman0001@gmail.com                                   %
%                 gaurav.dhiman@ieee.org                                  %
%                                                                         %
%       Homepage: http://www.dhimangaurav.com                             %
%                                                                         %
%  Published paper: G. Dhiman et al.                                      %
%          A novel algorithm for global optimization: Rat Swarm Optimizer %
%               Jounral of Ambient Intelligence and Humanized Computing   %
%               DOI: https://doi.org/10.1007/s12652-020-02580-0           %
%                                                                         %
%_________________________________________________________________________%
function[Leader_pos,Leader_score]=RSO(U,Y)
% initialize alpha, beta, and delta_pos
Max_iterations = 100;
SearchAgents_no = 100;
dim = 27;
Upper_bound=1;
Lower_bound=-1;
Leader_pos=zeros(1,dim);
Leader_score=inf; %change this to -inf for maximization problems
init_population;
fitness = zeros(1,SearchAgents_no);
l=0;
x = 1;
y = 2;
R = floor((y-x).*rand(1,1) + x);
while l<Max_iterations
   
    for i=1:SearchAgents_no  
        %xboundary
        [Ye,fitness(i)] = fun_completo(Positions(i,:)',U,Y,1);
        if fitness(i)<Leader_score
            Leader_score=fitness(i); 
            Leader_pos=Positions(i,:);
        end
    end
    A=R-l*((R)/Max_iterations); 
    
    
    for i=1:SearchAgents_no
        for j=1:dim   
            C=2*rand();          
            P_vec=A*Positions(i,j)+abs(C*((Leader_pos(j)-Positions(i,j))));                   
            P_final=Leader_pos(j)-P_vec;
            Positions(i,j)=P_final;
        end
    end
    l=l+1;    
end
