limi =0.001;
SalpPositions = [1*(2*rand(3,N) - 1) ; limi*(2*rand(dim-3,N) - 1)]';