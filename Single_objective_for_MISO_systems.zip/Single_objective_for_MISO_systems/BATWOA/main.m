%% Comando Executar %%
clear all
clc

load taruma.txt
% Estima��o 1
est = 827:941;
%est = 700:780;
Ue = taruma(est,1:6)';
Ye = taruma(est,10)'/1000;
runs=30;
ep=zeros(1,runs);
MSEest=zeros(1,runs);
xbest=zeros(27,runs);
tempo=zeros(1,runs);
for k=1:runs
tic
[xbest(:,k), MSEest(1,k)] = BATWOA(Ue,Ye);
tempo(1,k)= toc;
k
end
tam=length(Ye);
ym = mean(Ye');
Ym = ym'*ones(1,tam);
b = sum(sum((Ye-Ym).^2));
R2est = 1 - (MSEest*tam/b);
%valida��o
val = 960:1040;
% 
Uv = taruma(val,1:6)';
Yv = taruma(val,10)'/1000;

[Y_val, MSEval]  = fun_completo(xbest,Uv,Yv,runs);
tam=length(Yv);
ym = mean(Yv');
Ym = ym'*ones(1,tam);
b = sum(sum((Yv-Ym).^2));
R2val = 1 - (MSEval*tam/b);

[min,c] =min(MSEval);

figure(1)
%Estima��o
[Y_est, MSEest_best]  = fun_completo(xbest(:,c),Ue,Ye,1);
ye=Y_est{1,1};
%Valida��o

plot(Ye(1,:))
hold on
plot(ye(:,1))

figure(2)

[Y_val, MSEval_best]  = fun_completo(xbest(:,c),Uv,Yv,1);
yv=Y_val{1,1};
%Valida��o
plot(Yv(1,:))
hold on
plot(yv(:,1))

txt = 'Result Table2';
save (txt, 'xbest','MSEest','MSEval','R2est','R2val','MSEest_best','MSEval_best','tempo');
