limi =0.001;
Positions = [1*(2*rand(3,SearchAgents_no) - 1) ; limi*(2*rand(dim-3,SearchAgents_no) - 1)]';