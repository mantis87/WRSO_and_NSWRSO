clear all
clc

load taruma.txt
% Estimação 1
est = 827:941;
Ue = taruma(est,1:6)';
Ye = taruma(est,10)'/1000;

val = 960:1040;
Uv = taruma(val,1:6)';
Yv = taruma(val,10)'/1000;

load WRSO.mat
[c,n] = min(MSEval);
xb=xbest(:,n);
[Y_est_WRSO, MSEest_best]  = fun_completo(xb,Ue,Ye,1);
ye_WRSO=Y_est_WRSO{1,1};
[Y_val_WRSO, MSEval_best]  = fun_completo(xb,Uv,Yv,1);
yv_WRSO=Y_val_WRSO{1,1};

load GWO.mat
[c,n] = min(MSEval);
xb=xbest(:,n);
[Y_est_GWO, MSEest_best]  = fun_completo(xb,Ue,Ye,1);
ye_GWO=Y_est_GWO{1,1};
[Y_val_GWO, MSEval_best]  = fun_completo(xb,Uv,Yv,1);
yv_GWO=Y_val_GWO{1,1};

load WOAGWO.mat
[c,n] = min(MSEval);
xb=xbest(:,n);
[Y_est_WOAGWO, MSEest_best]  = fun_completo(xb,Ue,Ye,1);
ye_WOAGWO=Y_est_WOAGWO{1,1};
[Y_val_WOAGWO, MSEval_best]  = fun_completo(xb,Uv,Yv,1);
yv_WOAGWO=Y_val_WOAGWO{1,1};
subplot(2,1,1)
%figure(1)
%Estimação
plot(Ye(1,:),'k')
hold on
plot(ye_WRSO(:,1),'b')
plot(ye_GWO(:,1),'g')
plot(ye_WOAGWO(:,1),'r')
legend('Real signal','WRSO','GWO','WOAGWO')
title('Estimation')
xlim([0 115])
xlabel('Time (hours)')
ylabel('Water flow (m³/s)')
subplot(2,1,2)
%Validação
plot(Yv(1,:),'k')
hold on
plot(yv_WRSO(:,1),'b')
plot(yv_GWO(:,1),'g')
plot(yv_WOAGWO(:,1),'r')
legend('Real signal','WRSO','GWO','WOAGWO')
xlim([0 80])
title('Validation')
xlabel('Time (hours)')
ylabel('Water flow (m³/s)')